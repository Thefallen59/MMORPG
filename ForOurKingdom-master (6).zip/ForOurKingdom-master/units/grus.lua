return
{
	img = Image["Grus"],
	name = "Grus",
	hp = 750,
	dmg = 150,
	spd = .5,
	attackRate = 1.5,
	cost = 12,
	isFly = false,
	targetFly = false,
	targetGround = true,
	followTarget = false,
	range = 6,
}