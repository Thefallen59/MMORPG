return
{
	img = Image["Roco"],
	name = "Roco",
	hp = 350,
	dmg = 150,
	spd = 1.2,
	attackRate = 2,
	cost = 7,
	isFly = false,
	targetFly = false,
	targetGround = true,
	followTarget = false,
	animSpd = .12,
}