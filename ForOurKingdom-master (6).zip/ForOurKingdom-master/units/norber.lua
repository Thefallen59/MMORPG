return
{
	img = Image["Norber"],
	name = "Norber",
	hp = 2000,
	dmg = 200,
	spd = .40,
	attackRate = 2,
	cost = 19,
	isFly = false,
	targetFly = false,
	targetGround = true,
	followTarget = false,
}