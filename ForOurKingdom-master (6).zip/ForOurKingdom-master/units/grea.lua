return
{
	img = Image["Grea"],
	name = "Grea",
	hp = 1200,
	dmg = 125,
	spd = .60,
	attackRate = 1.25,
	cost = 15,
	isFly = false,
	targetFly = false,
	targetGround = true,
	followTarget = false,
}