return
{
	img = Image["Rockpose"],
	name = "Rockpose",
	hp = 140,
	dmg = 35,
	spd = 1,
	attackRate = .5,
	cost = 5,
	isFly = true,
	targetFly = true,
	targetGround = true,
	followTarget = true,
}