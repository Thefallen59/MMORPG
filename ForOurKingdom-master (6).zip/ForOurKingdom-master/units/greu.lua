return 
{
	img = Image["Greu"],
	name = "Greu",
	hp = 1500,
	dmg = 105,
	spd = .65,
	attackRate = 1.5,
	cost = 12,
	isFly = false,
	targetFly = false,
	targetGround = true,
	followTarget = false,
}