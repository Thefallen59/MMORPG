return 
{
	img = Image["Goblex"],
	name = "Goblex",
	hp = 100,
	dmg = 45,
	spd = 2,
	attackRate = .75,
	cost = 10,
	isFly = true,
	targetFly = true,
	targetGround = true,
	followTarget = true,
}