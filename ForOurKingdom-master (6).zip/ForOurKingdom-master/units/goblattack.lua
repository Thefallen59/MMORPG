return
{
	img = Image["Goblattack"],
	name = "Goblattack",
	hp = 35,
	dmg = 25,
	spd = 1.75,
	attackRate = .5,
	cost = 4,
	isFly = false,
	targetFly = true,
	targetGround = true,
	followTarget = false,
	range = 2
}